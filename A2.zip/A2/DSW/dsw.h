#ifndef DSW_H
#define DSW_H

#include <iostream>
#include <math.h>

using namespace std;

struct Node
{
    int data;
    Node* left;
    Node* right;

    Node(int val)
    {
        data = val;
        left = nullptr;
        right = nullptr;
    }
};

class BST 
{
    private:
        Node* root;

        // Helper functions
        void rotateRight(Node*& node);
        void rotateLeft(Node*& node);
        void createVine();  // Phase 1
        void rebuildTree(int size);  // Phase 2
        void performRotation(int count);  // helper for phase 2 (rebuildTree)
        void printTree(Node* root, int space);
        int countSubtreeUpTo3(Node* node);

    public:
        BST();
        ~BST();
        // helper for the destructor
        void deleteTree(Node*& node);

        void insert(int val);
        void dswBalance();

        void display();

};

#endif