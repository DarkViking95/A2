#include "dsw.h"
#include "customErrorClass.h"

// ----------------- PRIVATE ----------------------------------

// when left-heavy tree
void BST::rotateRight(Node*& node) // passing the parent
{
    if(node == nullptr || node->left == nullptr)
        throw MyException("No left child to rotate with");
    
    // get the node to rotate R
    Node* leftChild = node->left; 
    // leftnode's right child is going to become parent's left child
    node->left = leftChild->right;
    // parent is going to be right child of node that is rotated
    leftChild->right = node;
    
    node = leftChild;
}

// when right-heavy
void BST::rotateLeft(Node*& node)
{
    if(node == nullptr || node->right == nullptr)
        throw MyException("No right child to rotate with");

    // get the node to rotate L
    Node* rightChild = node->right;
    // rightnode's left child is going to become parent's right child
    node->right = rightChild->left;
    // parent is going to be left child of node that is rotated
    rightChild->left = node;

    node = rightChild;
}

int BST::countSubtreeUpTo3(Node* node)
{
    if (node == nullptr) 
        return 0;
        
    int count = 1; // Count the node itself

    // Check immediate children
    if (node->left != nullptr) 
        count++;
    
    if (node->right != nullptr) 
        count++;

    if (count >= 3) 
        return 3; // Exit early if we already have 3

    // Check all 4 possible grandchildren completely independently
    if (node->left != nullptr && node->left->left != nullptr) 
        count++;
    
    if (count >= 3) 
        return 3;

    if (node->left != nullptr && node->left->right != nullptr) 
        count++;
    
    if (count >= 3) 
        return 3;

    if (node->right != nullptr && node->right->left != nullptr) 
        count++;
    
    if (count >= 3) 
        return 3;

    if (node->right != nullptr && node->right->right != nullptr) 
        count++;

    return count;
}

// Phase 1 - partially left-skewed linked list tree
void BST::createVine()
{
    if (root == nullptr)
        throw MyException("Tree is empty");

    Node* grandparent = nullptr;
    Node* parent = root;

    while (parent != nullptr)
    {
        Node* rightChild = parent->right;
        if (rightChild != nullptr && countSubtreeUpTo3(rightChild) > 2) // right child with subtree > 2 exists
        {
            rotateLeft(parent);
            if (grandparent == nullptr)
                root = parent;

            else
                grandparent->left = parent;
        }
        else // no valid right child -> just keep moving
        {
            grandparent = parent;
            parent = parent->left;
        }
    }
}

// Phase 2
void BST::rebuildTree(int size)
{
    // how many left rotations do we need

    int h = (int)log2(size + 1);
    int m = (1 << h) - 1; // nodes in the perfect subtree
    //  (1 << h) same as pow(2,  h) = 2^h
    int extra = size - m; // extra nodes

    int targetH = 2 * h; // Calculate height of 2*log2(N)

    // initial rotation
    performRotation(extra);

    // subsequent rotations
    for (size = m / 2; size > 0; size /= 2) //if length of spine is close to balanced, we can skip rotations for small subtrees (size <= 2) since they are already balanced
    {
        if ((2 * size + 1) <= targetH)
        {
            break;
        }
        performRotation(size);
    }
}

// left rotate every second node based count
void BST::performRotation(int count)
{
    Node* grandparent = nullptr;
    Node* parent = root;
    
    for (int i = 0; i < count && parent != nullptr; i++)
    {
        if (parent->left == nullptr)
            throw MyException("Cannot perform left rotation: No left child to rotate with");

        // Rotate current node right
        rotateRight(parent);

        // Re-link rotated subtree to main vine
        if (grandparent == nullptr)
            root = parent;
        else
            grandparent->left = parent;
    
        // Advance down left-spine
        grandparent = parent;
        parent = parent->left;
    }
}

void BST::printTree(Node* root, int space) {
    const int COUNT = 10; 

    if (root == nullptr) {
        return;
    }

    // Increase the distance between levels
    space += COUNT;

    // Print the right child first (to appear on top)
    printTree(root->right, space);

    // Print the current node after right child

    for (int i = COUNT; i < space; i++) {
        cout << " "; // Indentation for tree depth
    }
    cout << root->data << endl;

    // Print the left child
    printTree(root->left, space);
}

// --------------------- PUBLIC ------------------
BST::BST()
{
    root = nullptr;
}

BST::~BST()
{
    deleteTree(root);
}

void BST::deleteTree(Node*& node)
{
    if(node == nullptr)
        return;
    
    deleteTree(node->left);
    deleteTree(node->right);

    delete node;
}

void BST::insert(int val)
{
    Node* newNode = new Node(val);
    if(root == nullptr){
        root = newNode;
        return;
    }
    
    Node* curr = root;
    Node*parent = nullptr;

    while(curr != nullptr)
    {
        parent = curr;
        if(val < curr->data)
            curr = curr->left;
        else
            curr = curr->right;
    }

    if(val < parent->data)
        parent->left = newNode;
    else
        parent->right = newNode;
}

void BST::dswBalance()
{
    if (root == nullptr)
        throw MyException("Tree is empty");

    // phase 1
    createVine();

    cout << "After phase 1:";
    display();

    int size = 0;
    Node* temp = root;
    while (temp != nullptr)
    {
        size++;
        temp = temp->left; //traverse down left side of vine instead
    }

    // phase 2
    rebuildTree(size);
}

void BST::display()
{
    cout << endl;
    printTree(root, 0);
    cout << endl;
}