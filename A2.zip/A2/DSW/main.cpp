#include "dsw.h"
#include "customErrorClass.h"

int main()
{
    BST bst1;

    cout << "Task 1" << endl;
    bst1.insert(20);
    bst1.insert(10);
    bst1.insert(30);
    bst1.insert(25);
    bst1.insert(40);
    bst1.insert(50); 
    
    cout << "Original BST:";
    bst1.display();
    
    // This will print "After phase 1:" internally
    bst1.dswBalance(); 
    
    cout << "Final DSW balanced BST:";
    bst1.display();

    BST bst2;
    cout << "Task 2" << endl;

    // Insert 10 through 70 in order, creating a massive right spine
    for (int i = 10; i <= 70; i += 10) {
        bst2.insert(i);
    }
    
    cout << "Original BST:";
    bst2.display();
    
    bst2.dswBalance();
    
    cout << "Final DSW balanced BST:";
    bst2.display();


    cout << "Edge Cases" << endl;
    BST bst3;
    bst3.insert(100);
    bst3.insert(50);
    
    cout << "Original BST (2 nodes):";
    bst3.display();
    
    try 
    {
        bst3.dswBalance();
        cout << "Final DSW balanced BST:";
        bst3.display();
    } 
    catch (MyException &e) 
    {
        cerr << e.what() << endl;
    }
    
    return 0;
    
}